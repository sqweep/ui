import 'package:flutter/material.dart';
const kMainColor = Color(0xFFAA00FF);
const kActiveColor = Color(0xFFFFD180);
const kAccentColor = Color(0xFFEF9920);
const kBodyTextColor = Color(0xFFFFD180);
const kInputColor = Color(0xFFFBFBFB);
const kBgColor = Color(0xFF303030);

const double defaultPadding = 16.0;